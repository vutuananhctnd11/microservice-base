package com.example.common_event_dto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonEventDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
