package com.example.common_event_dto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonEventDtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonEventDtoApplication.class, args);
	}

}
